const nanolog = require('@turbowarp/nanolog');
nanolog.enable();

module.exports = nanolog('vm');
