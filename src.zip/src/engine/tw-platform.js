// Forks should change this.
// This can be accessed externally on `vm.runtime.platform`

module.exports = {
    name: 'AstraEditor',
    url: "There is no link here..."
};
